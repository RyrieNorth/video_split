#!/usr/bin/env python
from .main import run
