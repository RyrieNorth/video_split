#!/usr/bin/env python
from video_split.main import main

if __name__ == "__main__":
    main()
